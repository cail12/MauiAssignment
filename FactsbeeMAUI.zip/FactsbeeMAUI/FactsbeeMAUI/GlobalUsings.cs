﻿global using System;
global using System.Collections.Generic;
global using System.Linq;
global using System.Text;
global using System.Threading.Tasks;

global using CommunityToolkit.Mvvm.ComponentModel;
global using CommunityToolkit.Mvvm.Input;

global using FactsbeeMAUI.Pages;
global using FactsbeeMAUI.ViewModels;
global using FactsbeeMAUI.Models;